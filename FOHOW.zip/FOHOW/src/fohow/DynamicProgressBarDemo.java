
import javax.swing.JFrame;


public class DynamicProgressBarDemo extends JFrame {
    public static void main(String[] args) {
        
                FOHOW1 pro = new FOHOW1();
                Login1 log = new Login1();
                pro.setVisible(true);
                try{
                    for(int i=0; i<100;i++){
                        Thread.sleep(60);
                        pro.jProgressBar2.setValue(i);
                        if(i==99){
                            pro.dispose();
                            log.setVisible(true);
                        }
                    }
                }catch(Exception e){
                    
                }
               DynamicProgressBarDemo demo = new DynamicProgressBarDemo();
                demo.setVisible(true);
            }
       
}