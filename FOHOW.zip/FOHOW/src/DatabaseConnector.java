import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class DatabaseConnector {

    public static final String URL = "jdbc:mysql://localhost:3306/FOHOW1";
    public static final String USER = "root";
    public static final String PASSWORD = "";
    Connection connection;
    public DatabaseConnector() {
        try {
            // Charger le pilote JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Établir la connexion à la base de données
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            
            if (connection != null) {
//                System.out.println("Connexion à la base de données établie !");
                // Vous pouvez maintenant exécuter des requêtes SQL ici
            }
        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
              JOptionPane.showMessageDialog(null,"Connection failed"+e.getMessage());
              
        }
    }
    
    public Connection maconn(){
        
        return connection;
    }

    PreparedStatement prepareStatement(String query) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from 
        return null;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from 
    }

    
    
        
}