
import java.awt.Image;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author wecingoma
 */
public final class Profile2 extends javax.swing.JFrame {
    DatabaseConnector con = new DatabaseConnector();
    methode met = new methode();
    NouveauPatient nouveua = new NouveauPatient();
    String num;
    String idUtilis;
    /**
     * Creates new form Profile2
     */
    public Profile2() {
//        initComponents();
    }
    public Profile2(String num) {
        this.num = num;
        initComponents();
        
        table(num,Table4);
        membre1(num,Table4);
        met.point_valeur(num, TOTALpv);
        met.bonus_courtier(num, FRANCmembre);
                
        
    }
    
    
    public Profile2(String num,String idUtilis) {
        this.num = num;
        initComponents();
        this.idUtilis = idUtilis;
        table(num,Table4);
        membre1(num,Table4);
        met.point_valeur(num, TOTALpv);
        met.bonus_courtier(num, FRANCmembre);
                
        
    }
    
    public void table(String i,JTable Table0){
        try{
        
        DefaultTableModel table2 = (DefaultTableModel)Table0.getModel();
        String query1 = "SELECT patients.nom_patient,patients.post_nom_patient,patients.prenom_patient,patients.sexe,facture_propre.Bonus_courtier,facture_propre.total_point_valeur FROM patients inner join membre on membre.id_membre = patients.id_membre inner join facture_propre on facture_propre.id_patient = patients.id_patient where membre.id_membre =?";
        PreparedStatement preparedStatement1 = con.maconn().prepareStatement(query1);
        preparedStatement1.setString(1, i);
        ResultSet rs = preparedStatement1.executeQuery();
        int it = 0;
        while(rs.next()){
        it +=1;
        table2.addRow(new Object[]{
            it,
            rs.getString("patients.nom_patient"),
            rs.getString("patients.post_nom_patient"),
            rs.getString("patients.prenom_patient"),
            rs.getString("patients.sexe"),
            rs.getString("facture_propre.Bonus_courtier"),
            rs.getString("facture_propre.total_point_valeur")
        });
        }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(this, "Erreur de la requette"+e.getMessage());
        }
    
    }
    
    public void membre1(String i,JTable Table0){
        try{
        
        String query1 = "SELECT * FROM membre where id_membre=?";
        PreparedStatement preparedStatement1 = con.maconn().prepareStatement(query1);
        preparedStatement1.setString(1, i);
        ResultSet rs = preparedStatement1.executeQuery();
        
            if (rs.next()) {
             
                
//            idmembre1    
            byte[] imageData = rs.getBytes("photo");
            String nom = rs.getString("nom_membre");
            String post_nom = rs.getString("post_nom");
            String prenom = rs.getString("Prenom");
            // Convertir les données binaires en objet Image
            if(imageData==null){
                //Affichage par defaut au cas o
//                imageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/svv.png"))); // NOI18N
                    // Affichage par défaut en cas de données d'image nulles
                ImageIcon defaultImageIcon = new ImageIcon(getClass().getResource("/svv.png")); 
                Image defaultImage = defaultImageIcon.getImage();

                // Redimensionner l'image par défaut pour s'adapter à la taille du JLabel
                int labelWidth = imageLabel.getWidth();
                int labelHeight = imageLabel.getHeight();
                Image scaledDefaultImage = defaultImage.getScaledInstance(labelWidth, labelHeight, Image.SCALE_SMOOTH);

                // Afficher l'image redimensionnée par défaut dans le JLabel
                imageLabel.setIcon(new ImageIcon(scaledDefaultImage));
            }else{
                    ImageIcon imageIcon = new ImageIcon(imageData);
                    Image image = imageIcon.getImage();

                    int labelWidth = imageLabel.getWidth();
                    int labelHeight = imageLabel.getHeight();

                    if (labelWidth > 0 && labelHeight > 0) {
                        // Redimensionner l'image pour s'adapter au JLabel sans dépasser si la taille du JLabel est valide
                        Image scaledImage = image.getScaledInstance(labelWidth, labelHeight, Image.SCALE_SMOOTH);
                        imageLabel.setIcon(new ImageIcon(scaledImage));
                    } else {
                        // Affichage par défaut si la taille du JLabel n'est pas valide
                        imageLabel.setIcon(new ImageIcon(getClass().getResource("/svv.png"))); // Chemin de l'image par défaut
                    }
//                ImageIcon imageIcon = new ImageIcon(imageData);
//                Image image = imageIcon.getImage();
//
//                // Afficher l'image dans un composant JLabel nommé "imageLabel"
//                imageLabel.setIcon(new ImageIcon(image));
            }
            
//            String nomMembre = rs.getString("nom_membre");
//            String postNom = rs.getString("post_nom");// Supposons que "nom" est le nom de la colonne contenant le nom du membre
//            String prenom = rs.getString("Prenom");
//            String photo = rs.getString("photo");
            // Vous pouvez récupérer d'autres colonnes de la même manière

            // Affichage du nom du membre dans un JTextField nommé "textFieldNomMembre"
//            nom_membre.setText(nomMembre);
//            post_nom.setText(postNom);
//            prenom1.setText(prenom);
            erreur.setText(i);
            erreur1.setText(nom);
            erreur2.setText(post_nom);
            erreur3.setText(prenom);
            
        } else {
            // Gérer le cas où aucune ligne n'est retournée par la requête
            erreur.setText("Aucun membre trouvé");
        }

        
        
        }catch(SQLException e){
            
        }
    
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        imageLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table4 = new javax.swing.JTable();
        imageLabel1 = new javax.swing.JLabel();
        TOTALpv = new javax.swing.JLabel();
        dollars = new javax.swing.JLabel();
        imageLabel2 = new javax.swing.JLabel();
        FRANCmembre = new javax.swing.JLabel();
        DateJoour = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        imageLabel3 = new javax.swing.JLabel();
        totalCDF = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        FRANCmembre1 = new javax.swing.JLabel();
        FRANCmembre2 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        TypeCompteMembre = new javax.swing.JComboBox<>();
        MembreMontant = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        MotifMembre = new javax.swing.JTextArea();
        jButton8 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        erreur1 = new javax.swing.JLabel();
        erreur2 = new javax.swing.JLabel();
        erreur3 = new javax.swing.JLabel();
        erreur = new javax.swing.JLabel();
        idmembre1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        imageLabel.setText("Photo");
        imageLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue, java.awt.Color.blue));
        imageLabel.setOpaque(true);

        jLabel5.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        jLabel5.setText("Patient associer");

        Table4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nom patient", "Post nom", "prenom", "SEXE", "Bonus courtier", "Point valeur"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Table4.setRowHeight(40);
        Table4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table4MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Table4);

        imageLabel1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        imageLabel1.setText("PV TOTAL : ");

        TOTALpv.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        dollars.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        imageLabel2.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        imageLabel2.setText("TOTAL CDF MEMBRE");

        FRANCmembre.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        DateJoour.setFont(new java.awt.Font("Monospaced", 1, 12)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Monospaced", 1, 12)); // NOI18N
        jLabel2.setText("Filtre par date");

        imageLabel3.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        imageLabel3.setText("Total CDF Journalier");

        totalCDF.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        jButton1.setFont(new java.awt.Font("Monospaced", 1, 12)); // NOI18N
        jButton1.setText("FITRE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        FRANCmembre1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        FRANCmembre1.setText("CDF");

        FRANCmembre2.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        FRANCmembre2.setText("CDF");

        jPanel30.setBackground(new java.awt.Color(2, 101, 104));
        jPanel30.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel64.setFont(new java.awt.Font("Liberation Sans", 1, 20)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setText("DÉPENSER");

        TypeCompteMembre.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        TypeCompteMembre.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Type de Compte", "Compte PV ", "Compte Massage", "Compte Consultation", "Compte Bonus Courtier" }));
        TypeCompteMembre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TypeCompteMembreActionPerformed(evt);
            }
        });

        MembreMontant.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        MembreMontant.setText(" ");
        MembreMontant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MembreMontantActionPerformed(evt);
            }
        });

        jLabel65.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 255, 255));
        jLabel65.setText("Compte   :");

        jLabel66.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("Montant  :");

        jLabel67.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(255, 255, 255));
        jLabel67.setText("Motif        :");

        MotifMembre.setColumns(20);
        MotifMembre.setFont(new java.awt.Font("Ubuntu", 1, 18)); // NOI18N
        MotifMembre.setRows(5);
        jScrollPane9.setViewportView(MotifMembre);

        jButton8.setBackground(new java.awt.Color(2, 101, 104));
        jButton8.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Effectuer la dépense");
        jButton8.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jLabel67, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel66, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(MembreMontant)
                    .addComponent(TypeCompteMembre, 0, 223, Short.MAX_VALUE)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel64))
                .addContainerGap(74, Short.MAX_VALUE))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel64)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TypeCompteMembre, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                    .addComponent(jLabel65))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MembreMontant, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel66))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel67)))
                .addGap(18, 18, 18)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        jPanel1.setBackground(new java.awt.Color(240, 240, 240));

        erreur1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        erreur2.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        erreur3.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        erreur.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        idmembre1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(erreur1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(erreur2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(erreur3, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(55, 55, 55)
                                .addComponent(erreur, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(idmembre1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(erreur1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(erreur2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(erreur3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(erreur, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(idmembre1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(3, 3, 3)
                .addComponent(imageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(238, 238, 238)
                        .addComponent(dollars, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(DateJoour, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(imageLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(TOTALpv, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(imageLabel2)
                        .addGap(26, 26, 26)
                        .addComponent(FRANCmembre, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(FRANCmembre1)
                        .addGap(46, 46, 46))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(imageLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(totalCDF, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FRANCmembre2)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(DateJoour, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(58, 58, 58)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dollars, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(imageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(imageLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(FRANCmembre2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(totalCDF, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(imageLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(FRANCmembre1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(TOTALpv, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(23, 23, 23))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(imageLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FRANCmembre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16))))
        );

        jLabel3.setFont(new java.awt.Font("Liberation Sans", 0, 24)); // NOI18N
        jLabel3.setText("<<<");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        jLabel1.setText("Compte Membre");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(73, 73, 73))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(537, 537, 537)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 712, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Table4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table4MouseClicked

    }//GEN-LAST:event_Table4MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        if(DateJoour.getDate() == null){
            JOptionPane.showMessageDialog(null, "Pas de case vide recommence","Attention",JOptionPane.INFORMATION_MESSAGE);

        }else{
            /*
            float point_v = 0;
        
            Date dateExpiration  = DateJoour.getDate();
   //        nompatient = nom.getText();
               // Formatage de la date dans le format JJMMAAAA

               SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
               String date_expiration_fhw = sdf.format(dateExpiration);

           String query1 = "SELECT sum(facture_propre.Bonus_courtier) as total_p "
                           + "FROM facture_propre "
                           + "INNER JOIN patients ON patients.id_patient = facture_propre.id_patient "
                           + "INNER JOIN membre ON membre.id_membre = patients.id_membre "
                           + "WHERE facture_propre.date_facture = ?";

           try (PreparedStatement preparedStatement1 = con.maconn().prepareStatement(query1)) {
               preparedStatement1.setString(1, date_expiration_fhw);

               try (ResultSet rs = preparedStatement1.executeQuery()) {
                   if (rs.next()) {
                       point_v = rs.getFloat("total_p");
                       totalCDF.setText(String.valueOf(point_v));

                   }
               }
           } catch (SQLException e) {
               // Affiche l'erreur pour débogage

           }
             
            */
        
           
        nouveua.effaceTable(Table4);
        met.bonus_courtierJournalier(this.num,totalCDF, DateJoour);
        met.bonus_courtierFiltre(num, Table4, DateJoour);
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TypeCompteMembreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TypeCompteMembreActionPerformed
        
    }//GEN-LAST:event_TypeCompteMembreActionPerformed

    private void MembreMontantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MembreMontantActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MembreMontantActionPerformed

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        dispose();
        Membres membre = new Membres();
        membre.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        if(MembreMontant.getText().equals("") || MotifMembre.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Pas de case ");
        }else if(TypeCompteMembre.getSelectedItem().equals("Type de Compte")){
            JOptionPane.showMessageDialog(this, "Le type doit être différent de Type de Compte");
        }else{
            String MembreMo = MembreMontant.getText();
            String TypeCoM =(String) TypeCompteMembre.getSelectedItem();
            String Motif = MotifMembre.getText();
            this.idUtilis = "1";
            try{
                String rq = "INSERT INTO depenseMembre(MotifDepense,typeCompte,date,id_membre,id_Utilisateur,montantMembre) VALUES(?,?,?,?,?,?)";
                
                PreparedStatement pr = con.maconn().prepareStatement(rq);
                pr.setString(1,Motif);
                pr.setString(2,TypeCoM);
                pr.setString(3, met.dateJour());
                pr.setString(4,this.num);
                pr.setString(5, this.idUtilis);
                pr.setString(6, MembreMo);
                pr.executeUpdate();
                
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, "Erreur"+e.getMessage());
            }
        }
        
            
       
        
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Profile2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Profile2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Profile2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Profile2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Profile2().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.toedter.calendar.JDateChooser DateJoour;
    private javax.swing.JLabel FRANCmembre;
    private javax.swing.JLabel FRANCmembre1;
    private javax.swing.JLabel FRANCmembre2;
    private javax.swing.JTextField MembreMontant;
    private javax.swing.JTextArea MotifMembre;
    private javax.swing.JLabel TOTALpv;
    private javax.swing.JTable Table4;
    private javax.swing.JComboBox<String> TypeCompteMembre;
    private javax.swing.JLabel dollars;
    private javax.swing.JLabel erreur;
    private javax.swing.JLabel erreur1;
    private javax.swing.JLabel erreur2;
    private javax.swing.JLabel erreur3;
    private javax.swing.JLabel idmembre1;
    private javax.swing.JLabel imageLabel;
    private javax.swing.JLabel imageLabel1;
    private javax.swing.JLabel imageLabel2;
    private javax.swing.JLabel imageLabel3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel totalCDF;
    // End of variables declaration//GEN-END:variables
}
