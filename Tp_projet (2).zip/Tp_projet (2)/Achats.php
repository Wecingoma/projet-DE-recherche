<?php
// $page = "Achats.php";
require_once ('controler.article/articleview.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Page d'acceuil SALEBUY_KAV</title>
  <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="style/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- CSS personnalisé -->
  <style>
    body {
      background-color: rgb(108, 213, 236); /* Couleur de fond */
    }

    .navbar {
      background-color: rgb(rgb(0, 204, 255)); /* Couleur de fond de la barre de navigation */
      border-radius: 8px;
    }

    .jumbotron {
      background: url(ImageHavard.jfif) ; /* Image de fond pour le jumbotron */
      background-size: contain;
      color: blue; /* Couleur du texte */
      height: 500px; /* Hauteur du jumbotron */
    }

    .product-card {
      border: 1px solid #eee; /* Bordure autour des cartes de produit */
      border-radius: 8px;
     
    }

    .payment-logos {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 30px;
      padding: 0 20px;
    }

    .payment-logos img {
      height: 40px; /* Taille des logos des moyens de paiement */
      margin-right: 20px; /* Espacement entre les logos */
    }

    .footer {
      background-color: #343a40; /* Couleur de fond du footer */
      color: #fff8f8; /* Couleur du texte */
      padding: 30px 0;
    }
    body {
      font-family: Arial, sans-serif;
      padding: 9px;
  }
  .carousel-video {
      max-width: 1800px;
      margin: 10 auto;
      height: 5px,
      
  }
  </style>
</head>
<body>

  <!-- Barre de navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="#">SALEBUY_KAV</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      </div>
        <!-- Barre de recherche--> 
  <div class="container-center">
    
    <table class="gh-tbl" role="presentation"><tbody><tr><td class="gh-td"><h1 id="gh-l-h1"><a href="https://www.ebay.com/" _sp="m570.l2586" id="gh-la"><img width="250" height="200" style="clip:rect(20px, 50px, 35px, 0px); position:absolute; top:-47px;left:0" alt="eBay Home" src="./Electronics, Cars, Fashion, Collectibles &amp; More _ eBay_files/fxxj3ttftm5ltcqnto1o4baovyl.png" id="gh-logo"></a></h1></td><td class="gh-td"><div id="gh-shop" class="gh-hide-if-nocss"><button id="gh-shop-a" aria-expanded="false" class="gh-control" aria-controls="gh-sbc-o"> SALEBUY_KAV<i id="gh-shop-ei" class="gh-sprRetina"></i></button><div id="gh-sbc-o" class="gh-o" style="display: none;"><h2 class="gh-ar-hdn">SALEBUY_KAV</h2><table id="gh-sbc" role="presentation"><tbody><tr><td><h3 class="gh-sbc-parent"><a title="" href="https://www.ebay.com/b/Collectibles-Art/bn_7000259855" _sp="m570.l3410">Collectibles &amp; art<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Collectibles/1/bn_1858810" _sp="m570.l3638">Collectibles</a></li><li><a class="scnd" href="https://www.ebay.com/b/Antiques/20081/bn_1851017" _sp="m570.l3636">Antiques</a></li><li><a class="scnd" href="https://www.ebay.com/b/Sports-Memorabilia-Fan-Shop-Sports-Cards/64482/bn_1857919" _sp="m570.l3639">Sports memorabilia</a></li><li><a class="scnd" href="https://www.ebay.com/b/Art/550/bn_1853728" _sp="m570.l45104">Art</a></li></ul><h3 class="gh-sbc-parent"><a title="Your shopping destination for the best selection and value in electronics and accessories" href="https://www.ebay.com/b/Electronics/bn_7000259124" _sp="m570.l3413">Electronics<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Computers-Tablets-Network-Hardware/58058/bn_1865247" _sp="m570.l3653">Computers &amp; tablets</a></li><li><a class="scnd" href="https://www.ebay.com/b/Cameras-Photo/625/bn_1865546" _sp="m570.l3654">Cameras &amp; photo</a></li><li><a class="scnd" href="https://www.ebay.com/b/TV-Video-Home-Audio-Electronics/32852/bn_1648392" _sp="m570.l3655">TV, audio &amp; surveillance</a></li><li><a class="scnd" href="https://www.ebay.com/b/Cell-Phones-Smart-Watches-Accessories/15032/bn_1865441" _sp="m570.l3652">Cell phones &amp; accessories</a></li></ul><h3 class="gh-sbc-parent"><a title="Your new destination for Clothing, Shoes &amp; Accessories on eBay" href="https://www.ebay.com/b/Fashion/bn_7000259856" _sp="m570.l3409">Fashion<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Womens-Clothing/15724/bn_661783" _sp="m570.l3632">Women</a></li><li><a class="scnd" href="https://www.ebay.com/b/Mens-Clothing/1059/bn_696958" _sp="m570.l3633">Men</a></li><li><a class="scnd" href="https://www.ebay.com/b/Jewelry-Watches/281/bn_1865273" _sp="m570.l3634">Jewelry &amp; watches</a></li><li><a class="scnd" href="https://www.ebay.com/b/Shoes/bn_7000259122" _sp="m570.l3635">Shoes</a></li></ul></td><td><h3 class="gh-sbc-parent"><a title="" href="https://www.ebay.com/b/Home-Garden/11700/bn_1853126" _sp="m570.l3412">Home &amp; garden<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Yard-Garden-Outdoor-Living-Items/159912/bn_1853607" _sp="m570.l3646">Yard, garden &amp; outdoor</a></li><li><a class="scnd" href="https://www.ebay.com/b/Art-Craft-Supplies/14339/bn_1851051" _sp="m570.l3647">Crafts</a></li><li><a class="scnd" href="https://www.ebay.com/b/Home-Improvement/159907/bn_1851980" _sp="m570.l4131">Home improvement</a></li><li><a class="scnd" href="https://www.ebay.com/b/Pet-Supplies/1281/bn_1853597" _sp="m570.l3773">Pet supplies</a></li></ul><h3 class="gh-sbc-parent"><a title="Buy and sell auto parts and accessories" href="https://www.ebay.com/b/Auto-Parts-Accessories/6028/bn_569479" _sp="m570.l45093">Auto Parts &amp; Accessories<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Car-GPS-Units/156955/bn_887051" _sp="m570.l45094">GPS &amp; Security Devices</a></li><li><a class="scnd" href="https://www.ebay.com/b/Car-Radar-Laser-Detectors/14935/bn_887006" _sp="m570.l45095">Radar &amp; Laser Detectors</a></li><li><a class="scnd" href="https://www.ebay.com/b/Automotive-Care-Detailing/179448/bn_1880904" _sp="m570.l45096">Care &amp; Detailing</a></li><li><a class="scnd" href="https://www.ebay.com/b/Scooter-Parts-Accessories/84149/bn_16582008" _sp="m570.l45097">Scooter Parts &amp; Accessories</a></li></ul><h3 class="gh-sbc-parent"><a title="" href="https://www.ebay.com/b/Musical-Instruments-Gear/619/bn_1865601" _sp="m570.l3772">Musical instruments &amp; gear<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Guitars-Basses/3858/bn_1865236" _sp="m570.l6384">Guitar</a></li><li><a class="scnd" href="https://www.ebay.com/b/Pro-Audio-Equipment/180014/bn_1865231" _sp="m570.l6385">Pro audio equipment</a></li><li><a class="scnd" href="https://www.ebay.com/b/String-Instruments/180016/bn_1865268" _sp="m570.l6386">String</a></li><li><a class="scnd" href="https://www.ebay.com/b/Stage-Lighting-Effects/12922/bn_1855494" _sp="m570.l6387">Stage lighting &amp; effects</a></li></ul></td><td><h3 class="gh-sbc-parent"><a title="" href="https://www.ebay.com/b/Sporting-Goods/888/bn_1865031" _sp="m570.l3414">Sporting goods<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Outdoor-Sports/159043/bn_1855398" _sp="m570.l3648">Outdoor sports</a></li><li><a class="scnd" href="https://www.ebay.com/b/Team-Sports/159049/bn_1865097" _sp="m570.l4135">Team sports</a></li><li><a class="scnd" href="https://www.ebay.com/b/Fitness-Running-Yoga-Equipment/15273/bn_1855426" _sp="m570.l3650">Exercise &amp; fitness</a></li><li><a class="scnd" href="https://www.ebay.com/b/Golf-Equipment/1513/bn_1849088" _sp="m570.l3651">Golf</a></li></ul><h3 class="gh-sbc-parent"><a title="" href="https://www.ebay.com/b/Toys-Hobbies/220/bn_1865497" _sp="m570.l3645">Toys &amp; hobbies<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/RC-Model-Vehicles-Toys-Control-Line/2562/bn_1851704" _sp="m570.l3415">Radio control</a></li><li><a class="scnd" href="https://www.ebay.com/b/Diecast-Toy-Vehicles/222/bn_1850842" _sp="m570.l3284">Kids toys</a></li><li><a class="scnd" href="https://www.ebay.com/b/Action-Figures/246/bn_1648288" _sp="m570.l1615">Action figures</a></li><li><a class="scnd" href="https://www.ebay.com/b/Dolls-Teddy-Bears/237/bn_1865477" _sp="m570.l4186">Dolls &amp; bears</a></li></ul><h3 class="gh-sbc-parent"><a title="" href="https://www.ebay.com/n/all-categories" _sp="m570.l3416">Other categories<i class="chevron-right"></i></a></h3><ul><li><a class="scnd" href="https://www.ebay.com/b/Video-Games-Consoles/1249/bn_1850232" _sp="m570.l3275">Video games &amp; consoles</a></li><li><a class="scnd" href="https://www.ebay.com/b/Beauty/bn_7000259123" _sp="m570.l3420">Health &amp; beauty</a></li><li><a class="scnd" href="https://www.ebay.com/b/Baby/2984/bn_1854104" _sp="m570.l3644">Baby</a></li><li><a class="scnd" href="https://www.ebay.com/b/Business-Industrial/12576/bn_1853744" _sp="m570.l3768">Business &amp; industrial</a></li></ul><h3 class="gh-sbc-parent"><a title="" href="https://www.ebay.com/n/all-categories" _sp="m570.l3601" id="gh-shop-see-all">See all categories<i class="gh-sbc-h3i gh-sprRetina"></i></a></h3></td></tr></tbody></table></div></div></td><td class="gh-td-s"><form id="gh-f" method="get" action="https://www.ebay.com/sch/i.html"><input type="hidden" value="R40" name="_from"><input type="hidden" name="_trksid" value="m570.l1313"><table class="gh-tbl2" id="gh-search-wrap" role="presentation"><tbody><tr><td class="gh-td-s"><div id="gh-ac-box"><div id="gh-ac-box2"><label for="gh-ac" class="gh-ar-hdn"></label><input type="text" class="gh-tb ui-autocomplete-input" aria-autocomplete="list" aria-expanded="false" size="50" maxlength="300" aria-label="Search for anything" placeholder="Search for anything" id="gh-ac" name="_nkw" autocapitalize="none" autocorrect="off" spellcheck="false" autocomplete="off" aria-haspopup="true" role="combobox" aria-owns="ui-id-1"><span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span><input style="display:none"><script> if(document.getElementById('gh-ac').value.length !== 0) { document.getElementById('gh-ac-box').classList.add('gh-ac-box-focus'); document.getElementById('gh').classList.add('gh-sch-focus'); } </script><svg aria-hidden="true" class="icon icon--search gh-search__icon" focusable="false" height="14" width="14"><use xlink:href="#icon-search"></use></svg> </div></div><div id="gAC"><ul class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" role="listbox" tabindex="-1" style="display: none; width: 571.073px;"></ul></div></td><td class="gh-td" id="gh-cat-td"><div id="gh-cat-box"><select aria-label="Select a category for search" class="gh-sb " size="1" id="gh-cat" name="_sacat"><option value="0">All Categories</option><option value="20081">Antiques</option><option value="550">Art</option><option value="2984">Baby</option><option value="267">Books</option><option value="12576">Business &amp; Industrial</option><option value="625">Cameras &amp; Photo</option><option value="15032">Cell Phones &amp; Accessories</option><option value="11450">Clothing, Shoes &amp; Accessories</option><option value="11116">Coins &amp; Paper Money</option><option value="1">Collectibles</option><option value="58058">Computers/Tablets &amp; Networking</option><option value="293">Consumer Electronics</option><option value="14339">Crafts</option><option value="237">Dolls &amp; Bears</option><option value="11232">DVDs &amp; Movies</option><option value="6000">eBay Motors</option><option value="45100">Entertainment Memorabilia</option><option value="172008">Gift Cards &amp; Coupons</option><option value="26395">Health &amp; Beauty</option><option value="11700">Home &amp; Garden</option><option value="281">Jewelry &amp; Watches</option><option value="11233">Music</option><option value="619">Musical Instruments &amp; Gear</option><option value="1281">Pet Supplies</option><option value="870">Pottery &amp; Glass</option><option value="10542">Real Estate</option><option value="316">Specialty Services</option><option value="888">Sporting Goods</option><option value="64482">Sports Mem, Cards &amp; Fan Shop</option><option value="260">Stamps</option><option value="1305">Tickets &amp; Experiences</option><option value="220">Toys &amp; Hobbies</option><option value="3252">Travel</option><option value="1249">Video Games &amp; Consoles</option><option value="99">Everything Else</option></select></div></td><td class="gh-td gh-sch-btn"><input type="submit" class="btn btn-prim gh-spr" id="gh-btn" value="Search"><svg aria-hidden="true" class="icon icon--search gh-search-btn__icon" focusable="false" height="22" width="22"><use xlink:href="#icon-search"></use></svg></td><td class="gh-td" id="gh-as-td"><a title="Advanced Search" href="https://www.ebay.com/sch/ebayadvsearch" aria-label="Advanced Search" _sp="m570.l2614" id="gh-as-a">Advanced</a></td></tr></tbody></table></form></td><td class="sticky_placeholder"><ul></ul></td></tr></tbody></table>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="">Accueil <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="produit.html">Produits</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Promotion.html">Promotions</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Categories.html">Categories</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="login.php">Se connecter</a>
          </li>
          
        </ul>
      </div>
   </div>
  </nav> 



  <!-- Jumbotron -->
  <div class=" jumbotron">
    <div class="container text-center">
      <h1 class="display-4">WELCOME TO SALEBUY_KAV</h1>
      <p class="lead">Découvrez des millions de produits à des prix imbattables.</p>
      <a class="btn btn-success btn-lg" href="TPPDR.html" role="button">back to acceuil</a>
    </div>
  </div>

  <div class="container">
    <div id="carouselExampleControls" class="carousel slide carousel-video" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <video class="d-block w-100" controls>
                    <source src="XiaoYing_Video_1719939277891.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
                <div class="carousel-caption d-none d-md-block">
                    <h5>Lancement en grande pompe</h5>
                    <p>Notre équipe vous accueille avec enthousiasme.</p>
                </div>
            </div>
            <div class="carousel-item">
                <video class="d-block w-100" controls>
                    <source src="XiaoYing_Video_1719939277891.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
                <div class="carousel-caption d-none d-md-block">
                    <h5>Conférences inspirantes</h5>
                    <p>Des intervenants de renom partagent leur expertise.</p>
                </div>
            </div>
            <div class="carousel-item">
                <video class="d-block w-100" controls>
                    <source src="XiaoYing_Video_1719939277891.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
                <div class="carousel-caption d-none d-md-block">
                    <h5>Ateliers interactifs</h5>
                    <p>Des sessions pratiques pour approfondir vos connaissances.</p>
                </div>
            </div>
            <!-- Ajoutez d'autres vidéos ici -->
        </div>
        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Précédent</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Suivant</span>
        </a>
    </div>
</div>
<br>
<br>
<br>



  
  <!-- Contenu principal (produits, promotions, etc.) -->
  
    <div class="container mt-4">
    <div class="row">
    <?php foreach($produits as $produit): ?>


      
      
      <div class="col-md-4 mb-4">
      <form action="">
        <div class="card product-card">
          <img src="data:image/jpg;base64<?= base64_encode($produit['photoArticle'])?>" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><?= $produit['NomArticle'] ?></h5>
            <p class="card-text"> <br> <?= $produit['Description'] ?>;<?=number_format($produit['Prix'],2,","," ")?>$.</p>
            
            <input type="submit" class="btn btn-success" value="Acheter">
            <a href="ajouterPanier.php?id=<?= $produit['idProduit'] ?>" class="add btn btn-primary">Ajouetz au Panier</a>
            
          </div>
        </div>
        </form>
      </div>


      
      <?php endforeach ?>
      
    </div>

  


  

  <!-- Affiches des moyens de paiement -->
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="payment-logos">
          <img src="VISA.jfif" alt="Visa">
          <img src="master carte.jfif" alt="MasterCard">
          <img src="Logo_m-pesa.jfif" alt="PayPal">
          <img src="americainExp.jfif" alt="American Express">
          <!-- Ajoutez d'autres logos de moyens de paiement ici -->
        </div>
    </div>
  </div>
</div>





  <footer class="bd-footer py-4 py-md-5 mt-5 bg-light">
    <div class="container py-4 py-md-5 px-4 px-md-3">
      <div class="row">
        <div class="col-lg-3 mb-3">
          <a class="d-inline-flex align-items-center mb-2 link-dark text-decoration-none" href="/" aria-label="Bootstrap">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="32" class="d-block me-2" viewBox="0 0 118 94" role="img"><title>SALEBUY_KAV</title><path fill-rule="evenodd" clip-rule="evenodd" d="M24.509 0c-6.733 0-11.715 5.893-11.492 12.284.214 6.14-.064 14.092-2.066 20.577C8.943 39.365 5.547 43.485 0 44.014v5.972c5.547.529 8.943 4.649 10.951 11.153 2.002 6.485 2.28 14.437 2.066 20.577C12.794 88.106 17.776 94 24.51 94H93.5c6.733 0 11.714-5.893 11.491-12.284-.214-6.14.064-14.092 2.066-20.577 2.009-6.504 5.396-10.624 10.943-11.153v-5.972c-5.547-.529-8.934-4.649-10.943-11.153-2.002-6.484-2.28-14.437-2.066-20.577C105.214 5.894 100.233 0 93.5 0H24.508zM80 57.863C80 66.663 73.436 72 62.543 72H44a2 2 0 01-2-2V24a2 2 0 012-2h18.437c9.083 0 15.044 4.92 15.044 12.474 0 5.302-4.01 10.049-9.119 10.88v.277C75.317 46.394 80 51.21 80 57.863zM60.521 28.34H49.948v14.934h8.905c6.884 0 10.68-2.772 10.68-7.727 0-4.643-3.264-7.207-9.012-7.207zM49.948 49.2v16.458H60.91c7.167 0 10.964-2.876 10.964-8.281 0-5.406-3.903-8.178-11.425-8.178H49.948z" fill="currentColor"></path></svg>
            <span class="fs-5">SALEBUY_KAV</span>
          </a>
          <ul class="list-unstyled small text-muted">
            <li class="mb-2">Designed and built with all the love in the world by the <a href="/docs/5.2/about/team/">SALEBUY_KAV team</a> with the help of <a href="https://github.com/twbs/bootstrap/graphs/contributors">our contributors</a>.</li>
            <li class="mb-2">Code licensed <a href="https://github.com/twbs/bootstrap/blob/main/LICENSE" target="_blank" rel="license noopener">MIT</a>, docs <a href="https://creativecommons.org/licenses/by/3.0/" target="_blank" rel="license noopener">CC BY 3.0</a>.</li>
            <li class="mb-2">Currently v5.2.3.</li>
          </ul>
        </div>
        <div class="col-6 col-lg-2 offset-lg-1 mb-3">
          <h5>Links</h5>
          <ul class="list-unstyled">
            <li class="mb-2"><a href="/">Home</a></li>
            <li class="mb-2"><a href="">produits</a></li>
            <li class="mb-2"><a href="/docs/5.2/examples/">Examples</a></li>
            <li class="mb-2"><a href="https://icons.getbootstrap.com/">Icons</a></li>
            <li class="mb-2"><a href="https://themes.getbootstrap.com/">Themes</a></li>
            <li class="mb-2"><a href="https://blog.getbootstrap.com/">Blog</a></li>
            <li class="mb-2"><a href="https://cottonbureau.com/people/bootstrap">Swag Store</a></li>
          </ul>
        </div>
        <div class="col-6 col-lg-2 mb-3">
          <h5>Guides</h5>
          <ul class="list-unstyled">
            <li class="mb-2"><a href="/docs/5.2/getting-started/">Getting started</a></li>
            <li class="mb-2"><a href="/docs/5.2/examples/starter-template/">Starter template</a></li>
            <li class="mb-2"><a href="/docs/5.2/getting-started/webpack/">Webpack</a></li>
            <li class="mb-2"><a href="/docs/5.2/getting-started/parcel/">Parcel</a></li>
            <li class="mb-2"><a href="/docs/5.2/getting-started/vite/">Vite</a></li>
          </ul>
        </div>
        <div class="col-6 col-lg-2 mb-3">
          <h5>Projects</h5>
          <ul class="list-unstyled">
            <li class="mb-2"><a href="https://github.com/twbs/bootstrap">salebuy_kav android</a></li>
            <li class="mb-2"><a href="https://github.com/twbs/bootstrap/tree/v4-dev">salebuy_kav pro</a></li>
            <li class="mb-2"><a href="https://github.com/twbs/icons">Icons</a></li>
            <li class="mb-2"><a href="https://github.com/twbs/rfs">RFS</a></li>
            <li class="mb-2"><a href="https://github.com/twbs/bootstrap-npm-starter">salebuy_kav ios</a></li>
          </ul>
        </div>
        <div class="col-6 col-lg-2 mb-3">
          <h5>Community</h5>
          <ul class="list-unstyled">
            <li class="mb-2"><a href="https://github.com/twbs/bootstrap/issues">Issues</a></li>
            <li class="mb-2"><a href="https://github.com/twbs/bootstrap/discussions">Discussions</a></li>
            <li class="mb-2"><a href="https://github.com/sponsors/twbs">Corporate sponsors</a></li>
            <li class="mb-2"><a href="https://opencollective.com/bootstrap">Open Collective</a></li>
            <li class="mb-2"><a href="https://stackoverflow.com/questions/tagged/bootstrap-5">Stack Overflow</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <p>&copy; 2024 SALEBUY_KAV. Tous droits réservés.</p>
        </div>
        <div class="col-md-6 text-right">
          <ul class="list-inline">
            <li class="list-inline-item"><a href="#">Conditions d'utilisation</a></li>
            <li class="list-inline-item"><a href="#">Confidentialité</a></li>
            <li class="list-inline-item"><a href="login1.php">Admin connect</a></li>
            <li class="list-inline-item"><a href="Admini.php">Page Administraction</a></li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Bootstrap JS, jQuery and Popper.js -->
  <script src="style/js/bootstrap.min.js"></script
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
