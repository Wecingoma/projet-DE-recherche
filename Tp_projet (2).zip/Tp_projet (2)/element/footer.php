        <footer class="footer">
            <div class="container">
            <div class="row">
                <div class="col-md-6">
                <p>&copy; 2024 SALEBUY_KAV. Tous droits réservés.</p>
                </div>
                <div class="col-md-6 text-right">
                <ul class="list-inline">
                    <li class="list-inline-item"><a href="#">Conditions d'utilisation</a></li>
                    <li class="list-inline-item"><a href="#">Confidentialité</a></li>
                    <li class="list-inline-item"><a href="#">Plan du site</a></li>
                </ul>
                </div>
            </div>
            </div>
        </footer>

  <!-- Bootstrap JS, jQuery and Popper.js -->
  