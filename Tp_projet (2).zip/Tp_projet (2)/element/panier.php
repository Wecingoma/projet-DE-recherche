<?php
class panier1{


public function __construct__(){

    if(!isset($_SESSION)){
        session_start();
    }
    if(!isset($_SESSION['panier'])){
        $_SESSION['panier'] = array();
    }
}

public function add($produi_id){
    // if(!isset($_SESSION['panier'][$produi_id])){
        $_SESSION['panier'][$produi_id] = 1;
    // }
    
}

}


?>