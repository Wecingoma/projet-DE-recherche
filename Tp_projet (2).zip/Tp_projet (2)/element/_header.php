<?php

require 'classe/function/methode.php';
require_once 'panier.php';
$panier = new panier1();

?>