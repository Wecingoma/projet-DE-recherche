<?php
function connectSession()  {
    if(session_start() === PHP_SESSION_NONE){
        session_start();

        
    }
    return $_SESSION['connected'];

}

