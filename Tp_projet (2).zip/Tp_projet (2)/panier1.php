<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panier</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .product-image {
      width: 100px;
      height: 100px;
      object-fit: cover;
    }
    .product-quantity input {
      width: 50px;
      text-align: center;
    }
    .product-total {
      font-weight: bold;
    }
    .cart-total {
      font-size: 1.2rem;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="container my-5">
    <h1 class="mb-4">Panier</h1>
    <table class="table">
      <thead>
        <tr>
          <th>Produit</th>
          <th>Prix</th>
          <th>Quantité</th>
          <th>Total</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <div class="d-flex align-items-center">
              <img src="product1.jpg" alt="Produit 1" class="product-image mr-3">
              <span>Produit 1</span>
            </div>
          </td>
          <td>19,99 €</td>
          <td class="product-quantity">
            <div class="input-group">
              <div class="input-group-prepend">
                <button class="btn btn-outline-secondary" type="button">-</button>
              </div>
              <input type="text" class="form-control" value="1">
              <div class="input-group-append">
                <button class="btn btn-outline-secondary" type="button">+</button>
              </div>
            </div>
          </td>
          <td class="product-total">19,99 €</td>
          <td>
            <button class="btn btn-danger btn-sm">Supprimer</button>
          </td>
        </tr>
        <tr>
          <td>
            <div class="d-flex align-items-center">
              <img src="product2.jpg" alt="Produit 2" class="product-image mr-3">
              <span>Produit 2</span>
            </div>
          </td>
          <td>29,99 €</td>
          <td class="product-quantity">
            <div class="input-group">
              <div class="input-group-prepend">
                <button class="btn btn-outline-secondary" type="button">-</button>
              </div>
              <input type="text" class="form-control" value="1">
              <div class="input-group-append">
                <button class="btn btn-outline-secondary" type="button">+</button>
              </div>
            </div>
          </td>
          <td class="product-total">29,99 €</td>
          <td>
            <button class="btn btn-danger btn-sm">Supprimer</button>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="row justify-content-end">
      <div class="col-md-4">
        <table class="table">
          <tbody>
            <tr>
              <td>Sous-total</td>
              <td class="text-right">49,98 €</td>
            </tr>
            <tr>
              <td>Frais de livraison</td>
              <td class="text-right">5,00 €</td>
            </tr>
            <tr>
              <td>Total</td>
              <td class="text-right cart-total">54,98 €</td>
            </tr>
          </tbody>
        </table>
        <div class="text-right">
          <button class="btn btn-primary">Valider la commande</button>
        </div>
      </div>
    </div>
  </div>
</body>
</html>