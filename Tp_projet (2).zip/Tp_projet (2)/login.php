<?php

require_once ('Autt.php');
require_once 'classe/function/methode.php';

$page = basename($_SERVER['SCRIPT_NAME']);
switch($page) {
    case 'login.php':
        if(!empty($_POST['email']) & !empty($_POST['pass'])) {
            $email = trim($_POST['email']);
            $password = trim($_POST['pass']);
            $password = md5($password);
            // $password = trim($_POST['pass']);
            // $password = md5($password);
            // $req = $db->prepare("SELECT idAdmin FROM ClientCompte WHERE email = ? AND password = ?");
            // $req->execute([$email, $password]);
            
            //$req = $pdo->prepare("SELECT idAdmin FROM Admistracteur WHERE GmailAdmin = ? AND motDePasse	 = ?");
            //$req->execute([$email, $password]);
            //$user = $req->fetch();
            $req = $pdo->prepare("SELECT id_client FROM ClientCompte WHERE Gmail = ? AND MotDepasse = ?");
            $req->execute([$email, $password]);
            $user = $req->fetch();
            var_dump($user);
            if(!empty($user)) {
                if(isset($_POST['remember'])) {
                    setcookie("user", $user['id'], time()+(3600*24*7));
                }
                setcookie("connected", $user['id_client'], time()+(3600*24*7));
                $_SESSION['connected'] = $user['id_client'];
                header('location: Achats.php');
            }
            //elseif(!empty($user1)){
            //    setcookie("connected", $user1['Gmail'], time()+(3600*24*7));
            //    $_SESSION['connected'] = $user1['Gmail'];
            //    header('location: Achats.php');
            //}
            else {
                setcookie('erreur', 'Email ou mot de passe incorrecte!', time()+10);
                header('location:login.php');
            }
        }else{
            echo 'ehec';
            break;
        }
            
        
        
    case 'register.php':
        if(!empty($_POST['nom']) & !empty($_POST['email']) &
            !empty($_POST['password']) & !empty($_POST['conf'])) {
                $nom = trim($_POST['nom']);
                $email = trim($_POST['email']);
                $password = trim($_POST['password']);
                $confirmation = trim($_POST['conf']);
                if($password == $confirmation) {
                    $password = md5($password);
                    if($_FILES['photo']['tmp_name']) {
                        $origine = $_FILES['photo']['tmp_name'];
                        $type = $_FILES['photo']['type'];
                        $extension = basename($type);
                        $name_file = time().".".$extension;
                        $destination = "files/profiles/$name_file";
                        if(move_uploaded_file($origine, $destination)) {
                        }
                    }
                    else {
                        $name_file = null;
                    }
                    $requete = $pdo->prepare("INSERT INTO ClientCompte (Gmail, Prenom, MotDepasse, photoClient) VALUES (?, ?, ?, ?)");
                    if($requete->execute([ $email,$nom, $password, $name_file])) {
                        header('location:login.php');
                    }
                    else {
                        setcookie("erreur", "Echec d'inscription", time()+5);
                        header('location:register.php');
                    }
                }
                else {
        setcookie("erreur", "Le mot de passe et la confirmation ne sont pas identiques", time()+5);
        header('location:register.php');
    }
}
        break;
    case 'mon_profil.php':
        break;
    case 'profil.php':
        break;

    case 'Admini.php':

        


    default:
    break;
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="style/css/bootstrap.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="styleTp.css">

</head>
<body>


   
<section class="form-container">
<?php
        if(isset($_COOKIE['erreur'])) {
        ?>
        <div class="alert alert-danger my-3"><?= $_COOKIE['erreur'] ?>
            
    </div>
        <?php
        }
        ?>
<?php if (!empty($err)): ?>
   <div class="alert alert-dange">
     
      <?= $err ?>
      
   </div>
   <?php endif; ?>
   <form action="" method="post">
      <h3>ESPEACE POUR UTILISATEUR !</h3>
      <input type="text" name="email" class="box" placeholder="enter your email" required><br><br>
      <input type="password" name="pass" class="box" placeholder="enter your password" required><br><br>
      <!-- <input type="file" name="photo" id=""> -->
      <input type="submit" value="connexion" class="btn btn-primary" name="submit"><br><br>
      <p>Vous avez deja un compte ?<a href="registre.php">Creer un compte !</a></p>
      
   </form>

</section>


</body>
</html>