<?php

require_once 'controler.article/insertion.php';

if(empty($_SESSION['connectedA'])){
  header('Location: Achats.php');
  exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/css/bootstrap.css">
</head>
<body><br><br>
<?php var_dump($_SESSION) ?>
        <?php
        if(isset($_COOKIE['erreur'])) {
          ?>
        <div class="alert alert-danger my-3"><?= $_COOKIE['erreur'] ?></div>
        
        <?php
        }
        ?>
        <?php
        if(isset($_COOKIE['connectedA'])) {
          ?>
        <div class="alert alert-danger my-3"><?= $_COOKIE['connectedA'] ?></div>
        
        <?php
        }
        ?>
<br>
<div class="container">
  <div class="row">
    <div class="col-md-4"><span class="card">
      <?php if(!empty($mess)): ?>
        <?= $mess ?>

        
      <?php endif; ?>
    </span></div>
    <div class="col-md-4">
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
      <h3>Inser les article !</h3>
      <input type="text" name="nomP" class="box" placeholder="Nom du produit" class="form-group"><br><br>
      <input type="File" name="photo" class="box" placeholder="enter your password" class="form-group"><br><br>
        <input type="number" name="prix" class="form-group" placeholder="Entrer le prix"><br><br>
      <input type="number" name="quantiter" id="" placeholder="Quantite Article"><br><br>
      <textarea name="annonce" id="" placeholder="Description du produit" class="form-group"></textarea><br><br>
      <!-- <input type="text" name="annonce" class="form-group" placeholder=""><br><b></b> -->
      <input type="submit" value="Enregistrer" class="btn btn-primary" name="submit" ><br><br>
      <!-- <p>Vous avez deja un compte ?<a href="register.php">Creer un compte !</a></p> -->
      
   </form>
    </div>
    <div class="col-md-4"></div>
  </div>
</div>


</body>
</html>