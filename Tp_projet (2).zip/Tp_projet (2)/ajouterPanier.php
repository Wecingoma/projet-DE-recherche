<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style/styleTp.css">
    <link rel="stylesheet" href="style/bootstrap.min.css">
</head>
<body>
    

<?php 
require'element/_header.php';
$mess =0;
// $Date1 = null;
if(isset($_GET['id'])){
    $Data = array('id' => $_GET['id']);
    $Date1 = $_GET['id'];
    $final = $pdo->prepare("SELECT idProduit FROM Produit where idProduit =?"); 
    $final->execute([$Date1]);
    $produit = $final->fetchAll();
    var_dump($produit);
    die('Le produit a ete ajouter  <a href="javascript:history.back()">Retour catologue</a>');

    if(empty($produit)){
        die("Ce produitn'existe pas ");
    }
    $panier->add($produit[0]->idProduit);
}else{
    $mess = "Votre Panier est vide";
}

?>
</body>
</html>

