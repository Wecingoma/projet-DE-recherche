#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: Admistracteur
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Admistracteur(
        idAdmin    Int UNSIGNED NOT NULL  AUTO_INCREMENT,
        GmailAdmin Varchar (100) NOT NULL unique,
        NomAdmi    Varchar (100) NOT NULL,
        MotDepasse Varchar (100) NOT NULL
	,CONSTRAINT Admistracteur_PK PRIMARY KEY (idAdmin)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Anonce
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Anonce(
        idAnnonce      Int NOT NULL AUTO_INCREMENT,
        annonceArticle Varchar (100) NOT NULL
	,CONSTRAINT Anonce_PK PRIMARY KEY (idAnnonce)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Produit
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Produit(
        idProduit  Int NOT NULL AUTO_INCREMENT,
        NomArticle Varchar (100) NOT NULL,
        photoArticle blob not null,
        Quantite  Int NOT NULL ,
        Prix Float NOT NULL ,
        idAnnonce  Int ,
        idAdmin int UNSIGNED  NOT NULL
	,CONSTRAINT Produit_PK PRIMARY KEY (idProduit)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Categorie
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Categorie(
        idCategorie        Int NOT NULL AUTO_INCREMENT,
        DescriptionProduit Varchar (100) NOT NULL ,
        idProduit  Int
	,CONSTRAINT Categorie_PK PRIMARY KEY (idCategorie)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Panier
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Panier(
        idProduit   Int NOT NULL AUTO_INCREMENT,
        id_panier   Int NOT NULL ,
        Article     Varchar (100) NOT NULL ,
        DateProduit Datetime NOT NULL ,
        NomArticle  Varchar (100) NOT NULL ,
        Quantite    Int NOT NULL ,
        Prix        Float NOT NULL ,
        idAdresse   Int NOT NULL,
        idAnnonce   Int  
	,CONSTRAINT Panier_PK PRIMARY KEY (idProduit,id_panier)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: ClientCompte
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ClientCompte(
        id_client  Int UNSIGNED NOT NULL AUTO_INCREMENT,
        Gmail      Varchar (100) NOT NULL unique,
        Prenom     Varchar (100) NOT NULL ,
        MotDepasse Varchar (100) NOT NULL ,
        idAdresse  Int NOT NULL
	,CONSTRAINT ClientCompte_PK PRIMARY KEY (id_client)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: AdresseClient
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS AdresseClient(
        idAdresse      Int NOT NULL AUTO_INCREMENT,
        NomPrenom      Varchar (100) NOT NULL ,
        Ville          Varchar (100) NOT NULL ,
        Gmail_client varchar(50) ,
        Comune         Varchar (100) NOT NULL ,
        Quartier       Varchar (100) NOT NULL ,
        Avenu          Varchar (100) NOT NULL ,
        NumeroParcelle Varchar (100) NOT NULL ,
        NumeroTel      Varchar (100) NOT NULL ,
        id_clientS  Int UNSIGNED
	,CONSTRAINT AdresseClient_PK PRIMARY KEY (idAdresse)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Commande
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS Commande(
        idCommande        Int NOT NULL AUTO_INCREMENT,
        Article           Varchar (100) NOT NULL ,
        QuantiteArticle   Int NOT NULL ,
        prixTotalCommande Float NOT NULL ,
        idAdresse         Int NOT NULL
	,CONSTRAINT Commande_PK PRIMARY KEY (idCommande)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: AchettterProduit
#------------------------------------------------------------

CREATE TABLE IF NOT EXISTS AchettterProduit(
        idProduit Int ,
        idAdresse Int
 	,CONSTRAINT AchettterProduit_PK PRIMARY KEY (idProduit,idAdresse)
)ENGINE=InnoDB;




ALTER TABLE Produit
	ADD CONSTRAINT Produit_Anonce0_FK
	FOREIGN KEY (idAnnonce)
	REFERENCES Anonce(idAnnonce);

ALTER TABLE Produit
	ADD CONSTRAINT Produit_Admistracteur1_FK
	FOREIGN KEY (idAdmin)
	REFERENCES Admistracteur(idAdmin);

ALTER TABLE Categorie
	ADD CONSTRAINT Categorie_Produit0_FK
	FOREIGN KEY (idProduit)
	REFERENCES Produit(idProduit);

ALTER TABLE Panier
	ADD CONSTRAINT Panier_Produit0_FK
	FOREIGN KEY (idProduit)
	REFERENCES Produit(idProduit);

ALTER TABLE Panier
	ADD CONSTRAINT Panier_AdresseClient1_FK
	FOREIGN KEY (idAdresse)
	REFERENCES AdresseClient(idAdresse);

ALTER TABLE Panier
	ADD CONSTRAINT Panier_Anonce2_FK
	FOREIGN KEY (idAnnonce)
    REFERENCES Anonce(idAnnonce);


ALTER TABLE AdresseClient
        ADD CONSTRAINT AdresseClient_PK_ANON
        FOREIGN KEY (id_clientS)
        REFERENCES ClientCompte(id_client);


