<?php 

class BaseDonne{
    private $host = 'localhost';
    private $username = 'root';
    private $password  = '';
    private $database = 'GestionBoutiaue';


    public function __construct($host = null , $username = null,$password = null ,$database = null)
    {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;
        
    }
    public function connectionBase(){
        
        try{
            $pdo = new PDO("mysql:host=localhost;dbname=E_commerce","root","");
            return $pdo;
        }catch(PDOException $e){
            echo"<script>alert('connection erreur');<script> $e";
        }
        

    }

    public function sessionStart(){
        if(session_status() === PHP_SESSION_NONE){
            session_start();
        }
        return !empty($_SESSION['conecte']);
    }



    // function acces($db) {
    //     if(!empty($_SESSION['connected'])) {
    //         $id = $_SESSION['connected'];
    //         $req = $db->prepare("SELECT * FROM users WHERE id = ?");
    //         $req->execute([$id]);
    //         $user = $req->fetch();
    //         if(empty($user)) {
    //             header('location: ../login/login.php');
    //         }
    //         else {
    //             return $user;
    //         }
    //     }
    //     elseif(!empty($_COOKIE['user'])) {
    //         $id = $_COOKIE['user'];
    //         $_SESSION['user'] = $id;
    //         $req = $db->prepare("SELECT * FROM users WHERE id = ?");
    //         $req->execute([$id]);
    //         $user = $req->fetch();
    //         if(empty($user)) {
    //             header('location:index.php');
    //         }
    //         else {
    //             return $user;
    //         }
    //     }
    //     else {
    //         header('location:index.php');
    //     }
    // }

    
}

?>

<?php
function est_connecter(): bool{
    if (session_status() === PHP_SESSION_NONE){
        session_start();
    }
    return !empty($_SESSION['conncete']);
}
?>




