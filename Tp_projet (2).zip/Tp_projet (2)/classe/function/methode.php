<?php

session_start();
try{
    $pdo = new PDO("mysql:host=localhost;dbname=E_commerce","root","");
    
}catch(PDOException $e){
    echo"<script>alert('connection erreur');<script> $e";
}
 
function acces($pdo) {
    if(!empty($_SESSION['connected'])) {
        $id = $_SESSION['connected'];
        $req = $pdo->prepare("SELECT id_client FROM ClientCompte WHERE id_client = ?");
        $req->execute([$id]);
        $user = $req->fetch();
        if(empty($user)) {
            header('location:login.php');
        }
        else {
            return $user;
        }
    }
    elseif(!empty($_COOKIE['connected'])) {
        $id = $_COOKIE['connected'];
        // $_SESSION['connected'] = $id;
        $req = $pdo->prepare("SELECT id_client FROM ClientCompte WHERE id_client = ?");
        $req->execute([$id]);
        $user = $req->fetch();
        if(empty($user)) {
            header('location: login.php');
        }
        else {
            return $user;
        }
    }
    else {
        header('location: login.php');
    }
}


function acces1($pdo) {
    if(!empty($_SESSION['connectedA'])) {
        $id = $_SESSION['connectedA'];
        $req = $pdo->prepare("SELECT idAdmin FROM Admistracteur WHERE idAdmin = ?");
        $req->execute([$id]);
        $user = $req->fetch();

        if(empty($user)) {
            header('location:login1.php');
        }
        else {
            return $user;
        }
    }
    elseif(!empty($_COOKIE['connected'])) {
        $id = $_COOKIE['connected'];
        // $_SESSION['connected'] = $id;
        $req = $pdo->prepare("SELECT idAdmin FROM Admistracteur WHERE idAdmin = ?");
        $req->execute([$id]);
        $user = $req->fetch();
        if(empty($user)) {
            header('location: login1.php');
        }
        else {
            return $user;
        }
    }
    else {
        header('location: login1.php');
    }
}


function dernierModification($pdo){
    $dernierId = $pdo->query("select max(idProduit) from Produit");
    $all = $dernierId->fetch();
    $_SESSION['dernier'] = $all['idProduit'];
    return $_SESSION['dernier'];
}


function formaterPrix($prix){

}