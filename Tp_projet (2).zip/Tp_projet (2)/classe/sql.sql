#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: Admistracteur
#------------------------------------------------------------

CREATE TABLE Admistracteur(
        GmailAdmin Varchar (100) NOT NULL ,
        NomAdmi    Varchar (100) NOT NULL
	,CONSTRAINT Admistracteur_PK PRIMARY KEY (GmailAdmin)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Anonce
#------------------------------------------------------------

CREATE TABLE Anonce(
        idAnnonce      Int NOT NULL Auto_increment,
        annonceArticle Varchar (100) NOT NULL
	,CONSTRAINT Anonce_PK PRIMARY KEY (idAnnonce)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Panier
#------------------------------------------------------------

CREATE TABLE Panier(
        id_panier   Int NOT NULL Auto_increment,
        Article     Varchar (100) NOT NULL ,
        DateProduit Datetime NOT NULL ,
        idAdresse   Int NOT NULL
	,CONSTRAINT Panier_PK PRIMARY KEY (id_panier)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Categorie
#------------------------------------------------------------

CREATE TABLE Categorie(
        idCategorie        Int NOT NULL Auto_increment,
        DescriptionProduit Varchar (100) NOT NULL ,
        idProduit          Int NOT NULL
	,CONSTRAINT Categorie_PK PRIMARY KEY (idCategorie)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: ClientCompte
#------------------------------------------------------------

CREATE TABLE ClientCompte(
        Gmail      Varchar (100) NOT NULL,
        Prenom     Varchar (100) NOT NULL ,
        MotDepasse Varchar (100) NOT NULL ,
        idAdresse  Int NOT NULL
	,CONSTRAINT ClientCompte_PK PRIMARY KEY (Gmail)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Produit
#------------------------------------------------------------

CREATE TABLE Produit(
        idProduit  Int NOT NULL Auto_increment,
        NomArticle Varchar (100) NOT NULL ,
        Quantite   Int NOT NULL ,
        idAnnonce  Int NOT NULL ,
        GmailAdmin Varchar (100) NOT NULL ,
        idAdresse  Int NOT NULL
	,CONSTRAINT Produit_PK PRIMARY KEY (idProduit)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: AdresseClient
#------------------------------------------------------------

CREATE TABLE AdresseClient(
        idAdresse      Int NOT NULL Auto_increment,
        NomPrenom      Varchar (100) NOT NULL ,
        Ville          Varchar (100) NOT NULL ,
        Comune         Varchar (100) NOT NULL ,
        Quartier       Varchar (100) NOT NULL ,
        Avenu          Varchar (100) NOT NULL ,
        NumeroParcelle Varchar (100) NOT NULL ,
        NumeroTel      Varchar (100) NOT NULL ,
        Gmail          Varchar (100) NOT NULL
	,CONSTRAINT AdresseClient_PK PRIMARY KEY (idAdresse)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Commande
#------------------------------------------------------------

CREATE TABLE Commande(
        idCommande        Int NOT NULL Auto_increment,
        Article           Varchar (100) NOT NULL ,
        QuantiteArticle   Int NOT NULL ,
        prixTotalCommande Float NOT NULL ,
        idAdresse         Int NOT NULL
	,CONSTRAINT Commande_PK PRIMARY KEY (idCommande)
)ENGINE=InnoDB;




ALTER TABLE Panier
	ADD CONSTRAINT Panier_AdresseClient0_FK
	FOREIGN KEY (idAdresse)
	REFERENCES AdresseClient(idAdresse);

ALTER TABLE Categorie
	ADD CONSTRAINT Categorie_Produit0_FK
	FOREIGN KEY (idProduit)
	REFERENCES Produit(idProduit);

ALTER TABLE ClientCompte
	ADD CONSTRAINT ClientCompte_AdresseClient0_FK
	FOREIGN KEY (idAdresse)
	REFERENCES AdresseClient(idAdresse);

ALTER TABLE ClientCompte 
	ADD CONSTRAINT ClientCompte_AdresseClient0_AK 
	UNIQUE (idAdresse);

ALTER TABLE Produit
	ADD CONSTRAINT Produit_Anonce0_FK
	FOREIGN KEY (idAnnonce)
	REFERENCES Anonce(idAnnonce);

ALTER TABLE Produit
	ADD CONSTRAINT Produit_Admistracteur1_FK
	FOREIGN KEY (GmailAdmin)
	REFERENCES Admistracteur(GmailAdmin);

ALTER TABLE Produit
	ADD CONSTRAINT Produit_AdresseClient2_FK
	FOREIGN KEY (idAdresse)
	REFERENCES AdresseClient(idAdresse);

ALTER TABLE AdresseClient
	ADD CONSTRAINT AdresseClient_ClientCompte0_FK
	FOREIGN KEY (Gmail)
	REFERENCES ClientCompte(Gmail);

ALTER TABLE AdresseClient 
	ADD CONSTRAINT AdresseClient_ClientCompte0_AK 
	UNIQUE (Gmail);

ALTER TABLE Commande
	ADD CONSTRAINT Commande_AdresseClient0_FK
    FOREIGN KEY (idAdresse)
    REFERENCES AdresseClient(idAdresse);



#	=======================================================================
	   Désolé, il faut activer cette version pour voir la suite du script ! 
#	=======================================================================
