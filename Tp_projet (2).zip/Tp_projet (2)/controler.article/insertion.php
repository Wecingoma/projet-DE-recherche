
<?php

require_once 'classe/function/methode.php';

$page = basename($_SERVER['SCRIPT_NAME']);
switch($page) {

    case 'Admini.php':
        // $db->acces($db);
         
            $id = acces1($pdo);
            if(isset($_POST['submit'])){
                if(!empty($_FILES['photo'])) {
                    $nomProduit = trim($_POST['nomP'])??null;
                    $quant = (int)$_POST['quantiter'];
                    $prix = (float)$_POST['prix'];
                    $annoce = nl2br(htmlentities($_POST['annonce']));
                    if ($_FILES['photo']['tmp_name']) {
                        $origine = $_FILES['photo']['tmp_name'];
                        // $type = $_FILES['photo']['type'];
                        $extension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
                        // $extension = basename($type);
                        $name_file = time().".".$extension;
                        $destination = "image/photoE";
                        $patheName = "image/photoE/$name_file";
                        $source_file = $origine;
                        $destination_file = $destination;

                        if(!is_dir($destination)){
                            mkdir($destination, 0755, true);
                        }
                        if(move_uploaded_file($origine, $destination)) {
                        
                        }else{
                            // echo "<div class="alert alert-dager" style = "color:red;text-align:centert;font-size:10px;"><script type="text">alert('echec enregistrement');<script>"</div>"";
                            echo "echec enregidtrement";
                        }
                        echo "Reponse";
                        if (rename($source_file, $destination_file)){
                            echo "fichier reussi";
                        }
                        else{
                            echo "Aucun deplacement ";
                        }
                        
                
                    }
                    else {
                        $name_file = null;
                    }
                    // function recuperDernierId()   {
                        
                    // }
                    $requete = $pdo->prepare("INSERT INTO Produit (NomArticle,Quantite,Prix,idAdmin,photoArticle,Description) VALUES (?, ?, ?, ?, ?, ?)");
                    
                    if($requete->execute([$nomProduit,$quant,$prix,$id['idAdmin'],$patheName,$annoce])) {
                        // $dernierId = getLastInsertedId($pdo, 'Produit');
                        // $dernierId = $pdo->insert_id();
                        $_SESSION = dernierModification($pdo);
                        //$der = $dernierId->fetch();
                        $_SESSION['dernier'] = $_SESSION;
                        
                        $idr = $_SESSION['dernier'];
                        if(isset($der)){
                            
                            $mess = null;
                            $req1 = $pdo->prepare("INSERT INTO Categorie(DescriptionProduit, idProduit) values(?,?)");
                            if($req1->execute([$annoce, $der])){
                                $mess = "Enregistrement reussi";
                            }
                        }
                        header('location: Achats.php');
                    }
                    else {
                        setcookie("erreur", "Echec d'enregistrement", time()+5);
                        header('location: Admini.php');
                    }
                        
                }
        
            }
            
            // $req = $pdo->query("SELECT (SELECT count(*) FROM comments WHERE comments.publication_id = comments.id) as nb_comment, (SELECT count(*) FROM reactions WHERE reactions.publication_id = publications.id) as nb_reaction, publications.id, publications.content, publications.created_at, publications.image, users.nom FROM publications LEFT JOIN users ON publications.user_id = users.id ORDER BY id DESC");
            // $publications = $req->fetchAll();

        break;
    case 'registre.php':
        if(!empty($_POST['nom']) & !empty($_POST['email']) &
        !empty($_POST['password']) & !empty($_POST['conf'])) {
            $nom = trim($_POST['nom']);
            $email = trim($_POST['email']);
            $password = trim($_POST['password']);
            $confirmation = trim($_POST['conf']);
            if($password == $confirmation) {
                $password = md5($password);
                if($_FILES['photo']['tmp_name']) {
                    $origine = $_FILES['photo']['tmp_name'];
                    $type = $_FILES['photo']['type'];
                    $extension = basename($type);
                    $name_file = time().".".$extension;
                    $destination = 'image/photos';
                    $name_fileP = "image/photos/$name_file";
                    // $origine, $destination
                    //  if(move_uploaded_file($_FILES['photo']['tmp_name'], $_FILES['photo']['name'])) {
                        // echo 'Telehcargement reussi';
                    //  }

                    if (!is_dir($destination)) {
                        mkdir($destination, 0755, true);
                    }
                     if(move_uploaded_file($name_file, $destination)) {
                        echo 'Telehcargement reussi';
                     }
                }
                else {
                    $name_file = null;
                }
                $requete = $pdo->prepare("INSERT INTO ClientCompte (Gmail, Prenom, MotDepasse, photoClient) VALUES (?, ?, ?, ?)");
                if($requete->execute([ $email,$nom, $password, $name_fileP])) {
                    header('location:login.php');
                }
                else {
                    setcookie("erreur", "Echec d'inscription", time()+5);
                    header('location:registre.php');
                }
            }
            else {
    setcookie("erreur", "Le mot de passe et la confirmation ne sont pas identiques", time()+5);
    header('location:registre.php');
    }
}




        break;

    case 'registre1.php':

                if(!empty($_POST['nom']) & !empty($_POST['email']) &
                !empty($_POST['password']) & !empty($_POST['conf'])) {
                    $nom = trim($_POST['nom']);
                    $email = trim($_POST['email']);
                    $password = trim($_POST['password']);
                    $confirmation = trim($_POST['conf']);
                    if($password == $confirmation) {
                        $password = md5($password);
                        if($_FILES['photo']['tmp_name']) {
                            $origine = $_FILES['photo']['tmp_name'];
                            $type = $_FILES['photo']['type'];
                            $extension = basename($type);
                            $name_file = time().".".$extension;
                            $destination = "files/profiles/$name_file";
                            // $origine, $destination
                             if(move_uploaded_file($_FILES['photo']['tmp_name'], $_FILES['photo']['name'])) {
                                echo 'Telehcargement reussi';
                             }
                        }
                        else {
                            $name_file = null;
                        }
                        $requete = $pdo->prepare("INSERT INTO Admistracteur (GmailAdmin, NomAdmi, MotDepasse) VALUES (?, ?, ?)");
                    if($requete->execute([ $email,$nom, $password])) {
                            header('location:login1.php');
                        }
                        else {
                            setcookie("erreur", "Echec d'inscription", time()+5);
                            header('location:registre1.php');
                        }
                    }
                    else {
            setcookie("erreur", "Le mot de passe et la confirmation ne sont pas identiques", time()+5);
            header('location:registre1.php');
            }
        }
            
        break;

    case 'Achats.php':

        // $req = $pdo->prepare("select * from Produit where Quantite > 0");

    default:
        
    break;
}
