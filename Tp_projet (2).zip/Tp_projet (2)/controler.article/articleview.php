<?php
require_once 'classe/function/methode.php';

$page = basename($_SERVER['SCRIPT_NAME']);

switch($page) {

    case 'Achats.php':
        // $db->acces($db);
        $id = acces($pdo);


        $req=$pdo->query("SELECT * FROM Produit ");
        //$produits1=$pdo->query("SELECT * FROM ClientCompte");
        $produits = $req->fetchAll();
        

        default:
        
    case 'ajouterPanier.php';
        
    break;
    }